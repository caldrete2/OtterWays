package com.example.otterairways;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.otterairways.DB.Account;
import com.example.otterairways.DB.AccountDAO;
import com.example.otterairways.DB.AppDB;


public class createAcc extends AppCompatActivity {

    private EditText usr;
    private EditText pswrd;
    private TextView results;
    private AccountDAO accountDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_acc);

        accountDAO = Room.databaseBuilder(this, AppDB.class, AppDB.DB_NAME)
                .allowMainThreadQueries()
                .build()
                .getAccountDAO();
    }

    public void checkInput(View v) {
        usr = (EditText)findViewById(R.id.loginName);
        pswrd = (EditText)findViewById(R.id.loginPswrd);
        results = (TextView) findViewById(R.id.accResults);

        String user = usr.getText().toString();
        String password = pswrd.getText().toString();
        Account userAcc = accountDAO.getUser(user);

        if(checkString(user) && checkString(password)) {
            if(userAcc == null) {
                accountDAO.insert(new Account(user, password));
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            } else { results.setText("Username already exist"); }
        }
        else
            results.setText("Error username/password do not meet criteria");
    }

    public boolean checkString(String s) {
        int count = 0;

        if(!s.equals("admin2")) {
            for(int i=0;i<s.length();i++) {
                if((s.charAt(i) >= 'a' && s.charAt(i) <= 'z') || (s.charAt(i) >= 'A' && s.charAt(i) <= 'Z'))
                    count++;
            }
        }

        if(count >= 3 && s.matches("(.*)[0-9](.*)") )
            return true;
        else
            return false;
    }
}