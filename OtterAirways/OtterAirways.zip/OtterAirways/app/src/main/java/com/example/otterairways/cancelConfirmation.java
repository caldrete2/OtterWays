package com.example.otterairways;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.otterairways.DB.AppDB;
import com.example.otterairways.DB.Flight;
import com.example.otterairways.DB.FlightDAO;
import com.example.otterairways.DB.Reservation;
import com.example.otterairways.DB.ReservationsDAO;

public class cancelConfirmation extends AppCompatActivity {

    private TextView cancelRes;
    private Intent intent;
    private Reservation reservation;
    private ReservationsDAO reservationsDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_confirmation);

        cancelRes = (TextView)findViewById(R.id.cancelRes);
        intent = getIntent();
        String f_id = intent.getStringExtra("flight_id");
        String r_id = intent.getStringExtra("res_id");
        f_id = f_id.replaceAll(" ", "");

        buildCancelConfirmation(f_id, r_id);
    }

    public void buildCancelConfirmation(String f_id, String r_id) {
        FlightDAO flightDAO = Room.databaseBuilder(this, AppDB.class, AppDB.DB_NAME)
                .allowMainThreadQueries()
                .build()
                .getFlightDAO();

        reservationsDAO = Room.databaseBuilder(this, AppDB.class, AppDB.DB_NAME)
                .allowMainThreadQueries()
                .build()
                .getReservationDAO();

        Flight flight = flightDAO.getFlightByID(f_id);
        reservation = reservationsDAO.getReservationByID(r_id);

        String s ="Reservation: "+r_id+" "+flight.toString()+" Tickets: "+ reservation.getTickets();
        cancelRes.setText(s);
    }

    public void onFinish(View v) {
        reservationsDAO.delete(reservation);
        intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
