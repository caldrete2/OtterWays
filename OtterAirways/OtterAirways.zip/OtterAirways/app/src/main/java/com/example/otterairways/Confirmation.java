package com.example.otterairways;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.otterairways.DB.Account;
import com.example.otterairways.DB.AccountDAO;
import com.example.otterairways.DB.AppDB;
import com.example.otterairways.DB.Flight;
import com.example.otterairways.DB.FlightDAO;
import com.example.otterairways.DB.Reservation;
import com.example.otterairways.DB.ReservationsDAO;

public class Confirmation extends AppCompatActivity {
    private TextView confirmRes;
    private FlightDAO flightDAO;
    private ReservationsDAO reservationsDAO;
    private Intent intent;
    private String flight;
    private String user;
    private String n;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        intent = getIntent();

        confirmRes = (TextView)findViewById(R.id.confirmRes);
        flightDAO = Room.databaseBuilder(this, AppDB.class, AppDB.DB_NAME)
                .allowMainThreadQueries()
                .build()
                .getFlightDAO();

        reservationsDAO = Room.databaseBuilder(this, AppDB.class, AppDB.DB_NAME)
                .allowMainThreadQueries()
                .build()
                .getReservationDAO();

        buildConfirmInfo();
    }

    private void buildConfirmInfo() {
        flight = intent.getStringExtra("flight_id");
        flight = flight.replace(" ", "");
        user = intent.getStringExtra("user");
        n = intent.getStringExtra("seats");
        Flight f = flightDAO.getFlightByID(flight);
        Double total = Integer.valueOf(n) * Double.valueOf(f.getPrice());

        String s = "User: "+user+"\nFlight: "+f.getFlight_id()+ "\nDeparture: "+f.getDeparture()+"\nArrival: "+f.getArrival()+"\nTime: "+f.getTime()+"\nTickets: "+n+" Total: $"+total;

        confirmRes.setText(s);
    }

    public void finishConfirmation(View v){
        insertReservation();
        intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void insertReservation() {
        String id = String.valueOf(reservationsDAO.getResCount()+1);
        reservationsDAO.insert(new Reservation(id, user, flight, n));
    }
}
